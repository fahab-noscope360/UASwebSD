<?php
include "../docs/header.php";
include "../docs/carousel.php";
include "../docs/about.php";
include "../docs/gallery.php";
include "../docs/team.php";
include "../docs/footer.php";
?>